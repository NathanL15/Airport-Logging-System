/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Nathan
 */
//Import statements
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Queue;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;

//Main Flight Class
public class FlightUI extends javax.swing.JFrame {
//	Variable declarations

	public static Queue<Integer> landing = new LinkedList<Integer>();
	public static Queue<Integer> takeoff = new LinkedList<Integer>();
	Timer t;
	int count = 0;
	int intervals = 0;
	int nextInLine = 0;
	int number = 5;
	int countDown = 4;
	int nextPlane = 0;
	boolean isLanding;

//	Class constructor
	public FlightUI() {
//		Sets up file and reads information
		initComponents();
		File arrivalFile = new File("arrivals.txt");
		File takeoffFile = new File("takeoffs.txt");
		try {
			readFile(arrivalFile, landing);
			readFile(takeoffFile, takeoff);
		} catch (FileNotFoundException ex) {

		}
//		Updates Queue
		updateQueue(0);
		updateQueue(1);
//		Sets up timer
		t = new Timer(600, new TimerListener());

	}
	
//	Timer class
	private class TimerListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
//			Prepares the timer variables and prints out the plane countdown
			intervals++;
			labelStatus2.setText(String.valueOf(countDown));
			countDown--;
			boolean action = false;
//			When there are planes that need to land
			if (landing.size() > 0) {
//				When the timer reaches the landing plane
				if (intervals % 5 == 0) {
//					Starts the animation, removes the plane from the queue, and prints out arrival message
					AnimationPanel.arrival();
					landing.remove();
					labelStatus.setText("Arrived");
					labelStatus2.setText("");
					action = true;
//					Updates arrival queue, and sets a new value for plane timer
					updateQueue(0);
					countDown = 4;
//					If there are no more planes to land
					if (landing.size() <= 0) {
//						Change the timer for takeoff
						countDown = 2;
						intervals = 10;
//						If there are planes to takeoff
						if (takeoff.size() > 0) {
//							Checks for the next takeoff plane
							nextPlane = takeoff.peek();
							isLanding = false;
						}
					} else {
//						Checks for next arriving plane
						nextPlane = landing.peek();
						isLanding = true;

					}
//					If there are no more planes to takeoff
					if (takeoff.size() <= 0) {
//						Set the timer appropriate for landing planes
						countDown = 4;
						intervals = 0;
						if (landing.size() > 0) {
//							Checks for the next landing planes
							nextPlane = landing.peek();
							isLanding = true;
						}
					}
//				If there are planes that are supposed to land
				} else if (intervals % 13 == 0 && !takeoff.isEmpty()) {
//					Removes the plane from the queue, and prints out depart message
					takeoff.remove();
					labelStatus.setText("Departed");
					labelStatus2.setText("");
					isLanding = false;
					action = true;
//					Checks for the next landing plane
					nextPlane = landing.peek();
					isLanding = true;
//					Updates the takeoff queue and sets new timer values
					updateQueue(1);
					intervals = 0;
					countDown = 4;
//					Starts the animation
					AnimationPanel.takeoff();

				}
//				Checks for takeoffs that are supposed to land
				if (intervals % 10 == 0 && intervals != 0) {
//					Sets the timer value and checks for the next takeoff plane.
					countDown = 2;
					nextPlane = takeoff.peek();
					isLanding = false;
				}

			} else {
//				If there are only planes to takeoff remaining
				if (takeoff.size() > 0) {
//					When the planes are supposed to takeoff
					if (intervals % 13 == 0 && intervals != 0) {
//						Remove the plane from the queue and print out depart message
						takeoff.remove();
						labelStatus.setText("Departed");
						labelStatus2.setText("");
						action = true;
						updateQueue(1);
//						Update the timer values
						intervals = 10;
						countDown = 2;
//						Start the animation
						AnimationPanel.takeoff();
//						If there are more planes to takeoff
						if (takeoff.size() > 0) {
//							Checks for the next takeoff plane 
							nextPlane = takeoff.peek();
							isLanding = false;
						}
					}
//				When there are no more planes in both queues
				} else {
//					Cleared queue status message
					labelStatus.setText("Plane list is empty");
					labelStatus2.setText("");
				}
			}
//			Prints out status message
			if (action == false && (landing.size() + takeoff.size()) > 0) {
				if (isLanding == true) {
					labelStatus.setText(Integer.toString(nextPlane) + " is landing in: ");
				} else {
					labelStatus.setText(Integer.toString(nextPlane) + " is leaving in: ");

				}
			}
		}
	}

	@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        textTakeoffs = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        textArrivals = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        fieldArriving = new javax.swing.JTextField();
        fieldTakeoff = new javax.swing.JTextField();
        buttonStart = new javax.swing.JButton();
        buttonQuit = new javax.swing.JButton();
        labelStatus2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        labelStatus = new javax.swing.JLabel();
        animationPanel1 = new AnimationPanel();
        labelError = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel1.setText("Airport Simulator");

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel2.setText("Press 'START' to begin simulation.");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel3.setText("Arrivals");

        textTakeoffs.setColumns(20);
        textTakeoffs.setRows(5);
        textTakeoffs.setFocusable(false);
        jScrollPane1.setViewportView(textTakeoffs);

        textArrivals.setColumns(20);
        textArrivals.setRows(5);
        textArrivals.setFocusable(false);
        jScrollPane2.setViewportView(textArrivals);

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel5.setText("Arriving Flight: ");

        jLabel6.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel6.setText("Takeoff Flight:");

        fieldArriving.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldArrivingActionPerformed(evt);
            }
        });

        fieldTakeoff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fieldTakeoffActionPerformed(evt);
            }
        });

        buttonStart.setText("Start");
        buttonStart.setFocusable(false);
        buttonStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonStartActionPerformed(evt);
            }
        });

        buttonQuit.setText("Quit");
        buttonQuit.setFocusable(false);
        buttonQuit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonQuitActionPerformed(evt);
            }
        });

        labelStatus2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jLabel7.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel7.setText("Takeoffs");

        labelStatus.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout animationPanel1Layout = new javax.swing.GroupLayout(animationPanel1);
        animationPanel1.setLayout(animationPanel1Layout);
        animationPanel1Layout.setHorizontalGroup(
            animationPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        animationPanel1Layout.setVerticalGroup(
            animationPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 168, Short.MAX_VALUE)
        );

        labelError.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(animationPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(88, 88, 88)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(103, 103, 103))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 34, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(79, 79, 79)
                                .addComponent(labelStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(labelStatus2, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(labelError, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldArriving, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(51, 51, 51)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fieldTakeoff, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(14, 14, 14))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(buttonQuit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(buttonStart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(animationPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelStatus2, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel3))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(fieldTakeoff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fieldArriving, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(buttonStart)
                        .addGap(34, 34, 34)
                        .addComponent(buttonQuit)))
                .addGap(18, 18, 18)
                .addComponent(labelError, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonStartActionPerformed
//		When start button is pressed
//		Checks the next landing plane
		nextPlane = landing.peek();
		isLanding = true;
//		Start the timer
		t.start();
    }//GEN-LAST:event_buttonStartActionPerformed

    private void fieldArrivingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldArrivingActionPerformed
//		When user inputs arriving planes
//		Checks if input is an integer
		if (checkInt(fieldArriving.getText()) == true) {
//			Starts the landing procedure if both queues were empty
			if (takeoff.size() + landing.size() <= 0) {
				intervals = 0;
				countDown = 4;
				nextPlane = Integer.parseInt(fieldArriving.getText());
				labelStatus.setText(fieldArriving.getText() + " is landing in: ");
			}
//			Adds the plane to the queue
			landing.add(Integer.parseInt(fieldArriving.getText()));
//			Resets the input field
			labelError.setText("");
			fieldArriving.setText("");
		} else {
//			Prompt when input is not an integer
			labelError.setText("Please enter an integer");
			fieldArriving.setText("");
		}
//		Updates the arrival queue
		updateQueue(0);
    }//GEN-LAST:event_fieldArrivingActionPerformed

    private void fieldTakeoffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fieldTakeoffActionPerformed
//		When user inputs departing planes
//		Checks if input is an integer
		if (checkInt(fieldTakeoff.getText()) == true) {
//			Starts the departing procedure if both queues were empty
			if (takeoff.size() + landing.size() <= 0) {
				intervals = 10;
				countDown = 2;
				nextPlane = Integer.parseInt(fieldTakeoff.getText());
				labelStatus.setText(fieldTakeoff.getText() + " is leaving in: ");
			}
//			Adds the plane to the queue
			takeoff.add(Integer.parseInt(fieldTakeoff.getText()));
//			Resets the input field
			labelError.setText("");
			fieldTakeoff.setText("");
		} else {
//			Prompt when input is not an integer
			labelError.setText("Please enter an integer");
			fieldTakeoff.setText("");
		}
//		Updates the departing queue
		updateQueue(1);
    }//GEN-LAST:event_fieldTakeoffActionPerformed

    private void buttonQuitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonQuitActionPerformed
//		Program exit button
		System.exit(0);
    }//GEN-LAST:event_buttonQuitActionPerformed

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {

		/* Set the Nimbus look and feel */
		//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
		/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(FlightUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(FlightUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(FlightUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(FlightUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		//</editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new FlightUI().setVisible(true);
			}
		});
//		
	}
//	Method to read starting file
	public static Queue<Integer> readFile(File file, Queue<Integer> q) throws FileNotFoundException {
//		Checks if there are any elements in the file
		Scanner sc = new Scanner(file);
		try {
//			Adds the elements to the queue
			while (true) {
				q.add(Integer.parseInt(sc.nextLine()));
			}
		} catch (NoSuchElementException e) {

		}
		sc.close();
		return q;
	}
	
//	Updates respective queues
	public void updateQueue(int choose) {
		String temp = "";
//		Arrival queue to be updated
		if (choose == 0) {
			StringTokenizer tokens = new StringTokenizer(landing.toString().substring(1, landing.toString().length() - 1), ", ");
			while (tokens.hasMoreElements()) {
				temp = temp + tokens.nextToken() + "\n";
			}
			textArrivals.setText(temp);
//		Takeoff queue to be updated
		} else if (choose == 1) {
			StringTokenizer tokens = new StringTokenizer(takeoff.toString().substring(1, takeoff.toString().length() - 1), ", ");
			while (tokens.hasMoreElements()) {
				temp = temp + tokens.nextToken() + "\n";
			}
			textTakeoffs.setText(temp);
		}
	}

//	Checks if the input is an integer
	public boolean checkInt(String input) {
		try {
			Integer.parseInt(input);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private AnimationPanel animationPanel1;
    private javax.swing.JButton buttonQuit;
    private javax.swing.JButton buttonStart;
    private javax.swing.JTextField fieldArriving;
    private javax.swing.JTextField fieldTakeoff;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel labelError;
    private javax.swing.JLabel labelStatus;
    private javax.swing.JLabel labelStatus2;
    private javax.swing.JTextArea textArrivals;
    private javax.swing.JTextArea textTakeoffs;
    // End of variables declaration//GEN-END:variables
}
